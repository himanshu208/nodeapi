# Create-RESTful-API-Using-Node.js-Express-4
Create RESTful API Using Node.js &amp; Express 4

##Tutorial
http://code.ciphertrick.com/2015/02/27/create-restful-api-using-node-js-express-4/

##Requirements
* Node and npm

##Installation

* Clone the repo : git clone  https://github.com/Inaamhusain/Create-RESTful-API-Using-Node.js-Express-4.git
* Install dependencies : npm install  
* Start the server : node server.js
